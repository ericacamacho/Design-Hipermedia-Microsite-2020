# microsite2020
Projeto de protótipo de website pessoal

Uma das valências conferidas pela cadeira de Design Hipermédia é o Web Design, mais especificamente utilizando HTML5, CSS3 e Javascript. Sendo assim, uma vez concluída o CTeSP - Tecnologias e Programação de Sistemas de Informação - é plausível o cenário em que tenha de realizar, rapidamente, um protótipo de Website para uma empresa.

Em termos técnicos, pretende-se que sejam concretizados os seguintes items:

(5 valores) – Estrutura de navegação funcional (entre as 5 páginas);

(3 valores) – Adaptação a dispositivos móveis (responsive design);

(2 valores) – Inclusão de um elemento programado (Javascript);

(5 valores) – Inclusão de elementos originais e marcação semântica desses conteúdos (HTML5);

(5 valores) – Design (CSS3).


* uma das páginas terá de ser realizada com Bootstrap 5, outra com FlexBox e outra com Grid. As restantes duas poderão usar qualquer uma destas alternativas mas será valorizado se for utilizado uma outra framework
